import { createContext} from "react";

const contex = createContext()

export default contex;